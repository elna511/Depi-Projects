﻿namespace Depi_c__Task5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtName = new TextBox();
            txtJob = new TextBox();
            DTpDOB = new DateTimePicker();
            ComboStatus = new ComboBox();
            RbtnFemale = new RadioButton();
            RbtnMale = new RadioButton();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            checkBox4 = new CheckBox();
            checkBox1 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            NUDSalary = new NumericUpDown();
            txtDescription = new TextBox();
            NUDCsharp = new NumericUpDown();
            Probar = new ProgressBar();
            btnReport = new Button();
            btnPageSetup = new Button();
            btnPreview = new Button();
            btnPrint = new Button();
            groupBox3 = new GroupBox();
            RtxtReport = new RichTextBox();
            pageSetupDialog1 = new PageSetupDialog();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printDialog1 = new PrintDialog();
            printPreviewDialog1 = new PrintPreviewDialog();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NUDSalary).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NUDCsharp).BeginInit();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 19);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 0;
            label1.Text = "Name :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 48);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 2;
            label2.Text = "Job :";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 87);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 4;
            label3.Text = "Birth day";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(301, 87);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 6;
            label4.Text = "Mstatus";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(306, 266);
            label5.Name = "label5";
            label5.Size = new Size(44, 15);
            label5.TabIndex = 10;
            label5.Text = "Salary :";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(57, 306);
            label6.Name = "label6";
            label6.Size = new Size(73, 15);
            label6.TabIndex = 6;
            label6.Text = "Description :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(82, 418);
            label7.Name = "label7";
            label7.Size = new Size(22, 15);
            label7.TabIndex = 14;
            label7.Text = "C#";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(249, 418);
            label8.Name = "label8";
            label8.Size = new Size(17, 15);
            label8.TabIndex = 16;
            label8.Text = "%";
            // 
            // txtName
            // 
            txtName.Location = new Point(82, 16);
            txtName.Name = "txtName";
            txtName.Size = new Size(424, 23);
            txtName.TabIndex = 0;
            // 
            // txtJob
            // 
            txtJob.Location = new Point(82, 45);
            txtJob.Name = "txtJob";
            txtJob.Size = new Size(424, 23);
            txtJob.TabIndex = 1;
            // 
            // DTpDOB
            // 
            DTpDOB.CustomFormat = "yyyy/MM/dd";
            DTpDOB.Format = DateTimePickerFormat.Custom;
            DTpDOB.Location = new Point(91, 83);
            DTpDOB.Name = "DTpDOB";
            DTpDOB.Size = new Size(200, 23);
            DTpDOB.TabIndex = 2;
            DTpDOB.Value = new DateTime(2025, 8, 7, 19, 27, 48, 0);
            DTpDOB.ValueChanged += DTpDOB_ValueChanged;
            // 
            // ComboStatus
            // 
            ComboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            ComboStatus.FormattingEnabled = true;
            ComboStatus.Items.AddRange(new object[] { "أعزب ", "متزوج ", "أرمل", "مطلق" });
            ComboStatus.Location = new Point(356, 83);
            ComboStatus.Name = "ComboStatus";
            ComboStatus.Size = new Size(121, 23);
            ComboStatus.TabIndex = 3;
            // 
            // RbtnFemale
            // 
            RbtnFemale.AutoSize = true;
            RbtnFemale.Location = new Point(103, 40);
            RbtnFemale.Name = "RbtnFemale";
            RbtnFemale.Size = new Size(63, 19);
            RbtnFemale.TabIndex = 1;
            RbtnFemale.Text = "Female";
            RbtnFemale.UseVisualStyleBackColor = true;
            // 
            // RbtnMale
            // 
            RbtnMale.AutoSize = true;
            RbtnMale.Checked = true;
            RbtnMale.Location = new Point(6, 40);
            RbtnMale.Name = "RbtnMale";
            RbtnMale.Size = new Size(51, 19);
            RbtnMale.TabIndex = 0;
            RbtnMale.TabStop = true;
            RbtnMale.Text = "Male";
            RbtnMale.UseVisualStyleBackColor = true;
            RbtnMale.CheckedChanged += RbtnMale_CheckedChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(RbtnFemale);
            groupBox1.Controls.Add(RbtnMale);
            groupBox1.Location = new Point(292, 137);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(207, 117);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Gender :";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(checkBox4);
            groupBox2.Controls.Add(checkBox1);
            groupBox2.Controls.Add(checkBox3);
            groupBox2.Controls.Add(checkBox2);
            groupBox2.Location = new Point(47, 137);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(150, 139);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "Habites";
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(6, 98);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(97, 19);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "Bodybuilding";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(6, 22);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(69, 19);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Football";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(6, 72);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(77, 19);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Watch TV";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(6, 47);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(83, 19);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "Swimming";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // NUDSalary
            // 
            NUDSalary.DecimalPlaces = 2;
            NUDSalary.Location = new Point(356, 262);
            NUDSalary.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            NUDSalary.Name = "NUDSalary";
            NUDSalary.Size = new Size(120, 23);
            NUDSalary.TabIndex = 11;
            NUDSalary.ThousandsSeparator = true;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(53, 324);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.ScrollBars = ScrollBars.Both;
            txtDescription.Size = new Size(446, 68);
            txtDescription.TabIndex = 7;
            // 
            // NUDCsharp
            // 
            NUDCsharp.Location = new Point(114, 414);
            NUDCsharp.Name = "NUDCsharp";
            NUDCsharp.Size = new Size(120, 23);
            NUDCsharp.TabIndex = 8;
            NUDCsharp.ValueChanged += NUDCsharp_ValueChanged;
            // 
            // Probar
            // 
            Probar.Location = new Point(272, 414);
            Probar.Name = "Probar";
            Probar.Size = new Size(178, 23);
            Probar.TabIndex = 17;
            Probar.Click += Probar_Click;
            // 
            // btnReport
            // 
            btnReport.Location = new Point(199, 529);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(126, 48);
            btnReport.TabIndex = 9;
            btnReport.Text = "Show Result ";
            btnReport.UseVisualStyleBackColor = true;
            btnReport.Click += btnReport_Click;
            // 
            // btnPageSetup
            // 
            btnPageSetup.Location = new Point(34, 508);
            btnPageSetup.Name = "btnPageSetup";
            btnPageSetup.Size = new Size(88, 35);
            btnPageSetup.TabIndex = 1;
            btnPageSetup.Text = "Page Setup";
            btnPageSetup.UseVisualStyleBackColor = true;
            btnPageSetup.Click += btnPageSetup_Click;
            // 
            // btnPreview
            // 
            btnPreview.Location = new Point(141, 508);
            btnPreview.Name = "btnPreview";
            btnPreview.Size = new Size(86, 35);
            btnPreview.TabIndex = 2;
            btnPreview.Text = "Preview";
            btnPreview.UseVisualStyleBackColor = true;
            btnPreview.Click += btnPreview_Click;
            // 
            // btnPrint
            // 
            btnPrint.Location = new Point(257, 508);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(85, 35);
            btnPrint.TabIndex = 3;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            btnPrint.Click += btnPrint_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(RtxtReport);
            groupBox3.Controls.Add(btnPrint);
            groupBox3.Controls.Add(btnPageSetup);
            groupBox3.Controls.Add(btnPreview);
            groupBox3.Location = new Point(533, 19);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(377, 587);
            groupBox3.TabIndex = 10;
            groupBox3.TabStop = false;
            groupBox3.Text = "Report :";
            // 
            // RtxtReport
            // 
            RtxtReport.Location = new Point(34, 41);
            RtxtReport.Name = "RtxtReport";
            RtxtReport.Size = new Size(308, 444);
            RtxtReport.TabIndex = 0;
            RtxtReport.Text = "";
            // 
            // pageSetupDialog1
            // 
            pageSetupDialog1.Document = printDocument1;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printDialog1
            // 
            printDialog1.Document = printDocument1;
            printDialog1.UseEXDialog = true;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(960, 721);
            Controls.Add(groupBox3);
            Controls.Add(btnReport);
            Controls.Add(Probar);
            Controls.Add(NUDCsharp);
            Controls.Add(txtDescription);
            Controls.Add(NUDSalary);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(ComboStatus);
            Controls.Add(DTpDOB);
            Controls.Add(txtJob);
            Controls.Add(txtName);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registration Application";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)NUDSalary).EndInit();
            ((System.ComponentModel.ISupportInitialize)NUDCsharp).EndInit();
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtName;
        private TextBox txtJob;
        private DateTimePicker DTpDOB;
        private ComboBox ComboStatus;
        private RadioButton RbtnFemale;
        private RadioButton RbtnMale;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private NumericUpDown NUDSalary;
        private TextBox txtDescription;
        private NumericUpDown NUDCsharp;
        private ProgressBar Probar;
        private Button btnReport;
        private Button btnPageSetup;
        private Button btnPreview;
        private Button btnPrint;
        private GroupBox groupBox3;
        private RichTextBox RtxtReport;
        private PageSetupDialog pageSetupDialog1;
        private PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
    }
}
