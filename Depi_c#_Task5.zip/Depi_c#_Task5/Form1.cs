namespace Depi_c__Task5
{
    public partial class Form1 : Form
    {
        #region Variables
        string Name;
        string Job;
        string DOB;
        string Statues;
        string Habites;
        string Gender;
        string Salary;
        string Description;
        string Csharp;

        #endregion
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void RbtnMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void DTpDOB_ValueChanged(object sender, EventArgs e)
        {

        }
        private void Probar_Click(object sender, EventArgs e)
        {

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Name = txtName.Text;
            Job = txtJob.Text;
            DOB = DTpDOB.Value.ToShortDateString();
            Statues = ComboStatus.Text;
            Gender = RbtnMale.Checked ? "Male" : "Female";
            Salary = NUDSalary.Value.ToString();
            Habites = string.Empty;
            if (checkBox1.Checked)
            {
                Habites += checkBox1.Text + ", ";
            }
            if (checkBox2.Checked)
            {
                Habites += checkBox2.Text + ", ";
            }
            if (checkBox3.Checked)
            {
                Habites += checkBox3.Text + ", ";
            }
            if (checkBox4.Checked)
            {
                Habites += checkBox4.Text;
            }
            Description = txtDescription.Text;
            Csharp = Probar.Value.ToString();
            RtxtReport.Text = $"------------------- you're Information -------------------\nName: {Name}\njob: {Job}\nDate of Birth: {DOB}\nStatus: {Statues}\nGender: {Gender}\nSalary: {Salary}\nHabites: {Habites}\nDescriptopn: {Description}\nCsharp: {Csharp}% ";



        }

        private void NUDCsharp_ValueChanged(object sender, EventArgs e)
        {
            Probar.Value = (int)NUDCsharp.Value;
        }

        private void btnPageSetup_Click(object sender, EventArgs e)
        {
            pageSetupDialog1.ShowDialog();
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(RtxtReport.Text, new Font("Tahoma" ,16) ,Brushes.Blue , 10,10 );
        }
    }
}
